from django.urls import path
from . import views

urlpatterns = [
    path('', views.sign_up),
    path('create', views.create_dojo),
    path('submit', views.submit_ninja_to_form),
    path('delete', views.delete)
]