from django.shortcuts import render, redirect
from .models import Dojos, Ninjas

def sign_up(request):
    context = {
        'all_dojos': Dojos.objects.all(),
    # dojo.id that we use in 51 of html is comming from dojo class id
        # 'all_ninjas': Ninjas.objects.all()
    }
    return render (request, 'sign_up.html', context)


# dont forget cama ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
# 10 get info from post and 
def create_dojo(request):
    print(request.POST)

    Dojos.objects.create(
        name=request.POST['name'],
        city=request.POST['city'],
        state=request.POST['state']
    )
    print(request.POST)
    return redirect ('/')

def submit_ninja_to_form(request):
    # 3) #  Dojo.objects.get(id=request.POST['dojo'])
    Ninjas.objects.create(
        # request.POST[dojo] come from the name of select
        dojo_id = Dojos.objects.get(id=request.POST['dojo']),
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name']
    )
    return redirect('/')

def delete(request):
    Dojos.objects.get(id=request.POST["delete"]).delete()

    return redirect("/")
