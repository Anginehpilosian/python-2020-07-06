from django.shortcuts import render, redirect
from .models import Book, Author

def book(request):
    # 2)  Im acceccing all Book class information that I typed in form and I posted
    context={
        'all_books' : Book.objects.all(),
    }
    return render(request, 'book.html', context)

def add_book(request):
    # 3) creating objects to access what we have from html file with POST
    Book.objects.create(
        title = request.POST['title'],
        description = request.POST['description']
    )
    return redirect('/')

#  6) creating context and passing id to a variable 'view_book
def book_list(request, book_id):
    context={
        'view_book' : Book.objects.get(id=book_id),
        'author_for_attach': Author.objects.all(),
    }
    return render (request, 'book_list.html', context)

def add_author_to_book(request, book_id):
    author = Author.objects.get(id=request.POST['author'])
    # adding authors to the book
    book = Book.objects.get(id=book_id)
    book.authors.add(author) 

    print(request.POST)
    return redirect(f'/book/{book_id}')

    # 2-1) starting againg 
def author(request):
    # 2-2)  Im acceccing all Author class information that I typed in form and I posted
    context={
        'all_authors' : Author.objects.all(),
    }
    return render(request, 'author.html', context)

def add_author(request):
    # 2-3) creating objects to access what we have from html file with POST
    Author.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        notes = request.POST['notes'],
    )
    return redirect('/author')

def author_list(request, author_id):
    # to be able to see Author class information which passing by id from previus page we need context
    context={
        'view_all_authors' : Author.objects.get(id=author_id),
        'book_for_attach' : Book.objects.all()
    }
    return render (request, 'author_list.html', context)

def add_book_to_author(request, author_id):
    onebook = Book.objects.get(id=request.POST['book'])
    # or
    # book_id = request.POST['book']
    # onebook=Book.objects.get(id=book_id) to be saved
    # we want to save this specific author id what book we adding to it
    # and be able to see whenever we come back in that author id see books list
    author = Author.objects.get(id=author_id)
    # add onebook, specific book to the author books
    author.books.add(onebook)

    return redirect (f'/author/{author_id}')