from django.apps import AppConfig


class BookAuthorAppConfig(AppConfig):
    name = 'book_author_app'
