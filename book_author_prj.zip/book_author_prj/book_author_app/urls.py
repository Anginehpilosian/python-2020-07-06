from django.urls import path
from .import views

urlpatterns = [
    path('', views.book),
    path('book', views.add_book),
    path('book/<int:book_id>', views.book_list),
    path('book/<int:book_id>/add_author', views.add_author_to_book),
    path('author', views.author),
    path('add_author', views.add_author),
    path('author/<int:author_id>', views.author_list),
    path('author/<int:author_id>/add_book', views.add_book_to_author),
    ]