from django.apps import AppConfig


class DisplayTimeAppConfig(AppConfig):
    name = 'display_time_app'
